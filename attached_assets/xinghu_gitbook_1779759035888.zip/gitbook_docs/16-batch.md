# Пакетные запросы Python

> ⚠️ Рекомендуется использовать `aiohttp` вместо `httpx` — он значительно эффективнее для параллельных запросов.

---

## Советы по пакетным запросам

- Используйте `aiohttp` для асинхронных параллельных запросов
- Записывайте результаты по мере получения (не ждите завершения всех)
- Не отправляйте слишком много запросов из одного скрипта — это может переполнить TCP-соединения
- При необходимости запустите несколько независимых скриптов параллельно
- Обязательно обрабатывайте ошибки — даже официальный OpenAI не гарантирует 100% успех

---

## Пример: базовый запрос

```python
import aiohttp
import asyncio
import json

API_KEY = "sk-ВАШ_КЛЮЧ"
BASE_URL = "https://xinghuapi.com/v1"

async def chat(session, prompt):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    body = {
        "model": "gemini-2.5-pro-all",
        "messages": [{"role": "user", "content": prompt}]
    }
    async with session.post(f"{BASE_URL}/chat/completions", headers=headers, json=body) as resp:
        data = await resp.json()
        return data["choices"][0]["message"]["content"]

async def main():
    prompts = ["Что такое Python?", "Что такое API?", "Объясни asyncio"]
    async with aiohttp.ClientSession() as session:
        tasks = [chat(session, p) for p in prompts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for i, result in enumerate(results):
            print(f"[{i+1}] {result}\n")

asyncio.run(main())
```

---

## Пример: запись результатов по мере получения

```python
import aiohttp
import asyncio

API_KEY = "sk-ВАШ_КЛЮЧ"
BASE_URL = "https://xinghuapi.com/v1"

async def process_item(session, item_id, prompt, output_file):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    body = {
        "model": "claude-sonnet-4-6",
        "messages": [{"role": "user", "content": prompt}]
    }
    try:
        async with session.post(f"{BASE_URL}/chat/completions", headers=headers, json=body) as resp:
            data = await resp.json()
            result = data["choices"][0]["message"]["content"]
            # Сразу записываем результат
            with open(output_file, "a", encoding="utf-8") as f:
                f.write(f"ID {item_id}: {result}\n\n")
            return True
    except Exception as e:
        print(f"Ошибка для ID {item_id}: {e}")
        return False

async def main():
    items = [(1, "Переведи: Hello"), (2, "Переведи: World"), (3, "Переведи: Python")]
    async with aiohttp.ClientSession() as session:
        tasks = [process_item(session, id_, prompt, "results.txt") for id_, prompt in items]
        results = await asyncio.gather(*tasks)
        print(f"Успешно: {sum(results)}/{len(results)}")

asyncio.run(main())
```
