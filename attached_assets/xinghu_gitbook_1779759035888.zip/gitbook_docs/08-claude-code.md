# Claude Code

> Claude Code — мощный AI-ассистент для программирования прямо в терминале.

---

## Системные требования

- Node.js **v18.0+**
- ОС: macOS, Linux, Windows (WSL)

---

## Шаг 1: Установка Node.js

**Windows:** скачайте с [nodejs.org](https://nodejs.org/zh-cn) и установите.

**Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo bash -
sudo apt-get install -y nodejs
```

**macOS:**
```bash
brew install node
```

---

## Шаг 2: Установка Claude Code

```bash
npm install -g @anthropic-ai/claude-code
claude --version
```

---

## Шаг 3: Параметры конфигурации

| Параметр | Описание | Как получить |
|---|---|---|
| `ANTHROPIC_AUTH_TOKEN` | Токен аутентификации | Раздел «API-токены» панели управления (формат `sk-`) |
| `ANTHROPIC_BASE_URL` | Адрес API | `https://xinghuapi.com` |

---

## Шаг 4: Запуск

**Windows (cmd):**
```cmd
cd папка-с-проектом
set ANTHROPIC_AUTH_TOKEN=sk-...
set ANTHROPIC_BASE_URL=https://xinghuapi.com
claude
```

**macOS / Linux:**
```bash
cd папка-с-проектом
export ANTHROPIC_AUTH_TOKEN=sk-...
export ANTHROPIC_BASE_URL=https://xinghuapi.com
claude
```

---

## Использование в VS Code

> ⚠️ Claude Code по умолчанию требует аккаунт Claude или API-разработчика. Для работы с Xinghu API сначала настройте системные переменные окружения.

**Шаг 1:** Откройте **Системные переменные окружения Windows** и добавьте:
- `ANTHROPIC_AUTH_TOKEN` = ваш токен Xinghu
- `ANTHROPIC_BASE_URL` = `https://xinghuapi.com`

**Шаг 2:** Установите расширение **«Claude Code»** из маркетплейса VS Code. После установки значок появится в правом верхнем углу редактора.

---

## Частые вопросы

**«Invalid API Key · Please run /login»**  
→ Переменные окружения не заданы или заданы неверно.

**Статус «offline»**  
→ Claude Code проверяет доступность Google. Это не мешает работе.

**Fetch failed**  
→ Нужно стабильное международное интернет-соединение.
