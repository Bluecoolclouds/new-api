# VS Code — Claude Code + Cline

---

## Подготовка

### 1. Получить API-ключ
1. Зайдите на [xinghuapi.com](https://xinghuapi.com/) и зарегистрируйтесь
2. Панель управления → **Управление токенами → Создать токен**
3. Группа: «Claude Code — эксклюзивная группа» или другая группа Claude
4. Скопируйте ключ `sk-xxxxx`

### 2. Установить Node.js (v18+)
Скачайте с [nodejs.org](https://nodejs.org) и установите. Проверьте:
```bash
node --version
```

### 3. Установить Git
Скачайте с [git-scm.com](https://git-scm.com). Windows: отметьте «Add Git to PATH».

---

## Настройка Claude Code в VS Code

### Метод 1: через settings.json

Откройте VS Code → **Настройки** → введите «claude» → откройте `settings.json`. Добавьте:

```json
{ "name": "ANTHROPIC_BASE_URL", "value": "https://xinghuapi.com" },
{ "name": "ANTHROPIC_AUTH_TOKEN", "value": "sk-ВАШ_КЛЮЧ" }
```

Сохраните и перезапустите Claude Code.

### Метод 2: через переменные окружения

**Windows (PowerShell):**
```powershell
$env:ANTHROPIC_AUTH_TOKEN="sk-..."
$env:ANTHROPIC_BASE_URL="https://xinghuapi.com"
```

**macOS / Linux:**
```bash
export ANTHROPIC_AUTH_TOKEN="sk-..."
export ANTHROPIC_BASE_URL="https://xinghuapi.com"
```

---

## Настройка плагина Cline

| Поле | Значение |
|---|---|
| API Provider | OpenAI Compatible |
| Base URL | `https://xinghuapi.com/v1` |
| API Key | Ваш токен Xinghu |
| Model ID | Например `claude-sonnet-4-6` |

### Рекомендуемые группы токенов

| Группа | Модели |
|---|---|
| Claude Code — эксклюзивная группа | Серия Claude |
| Группа Codex | Серия GPT |

---

## Рекомендуемые модели Claude

| Модель | ID | Лучше для |
|---|---|---|
| Claude Sonnet 4.6 | `claude-sonnet-4-6` | Ежедневная разработка |
| Claude Opus 4.6 | `claude-opus-4-6` | Сложные задачи, архитектура |
| Claude Haiku 4.5 | `claude-haiku-4-5-20251001` | Быстрые ответы |

---

## Решение типичных проблем

| Проблема | Решение |
|---|---|
| Ошибка подключения | Проверьте URL: `https://xinghuapi.com/v1` |
| 401 Unauthorized | Ключ скопирован с пробелом или просрочен |
| Модель не найдена | Проверьте ID и группу токена |
| 429 Too Many Requests | Проверьте баланс, снизьте частоту запросов |
| Claude Code не запускается | Windows: запустите от имени администратора |
| Медленный ответ | Переключитесь на Haiku или сократите контекст |
