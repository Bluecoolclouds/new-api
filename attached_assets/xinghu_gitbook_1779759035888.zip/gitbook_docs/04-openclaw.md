# Настройка API в OpenClaw

OpenClaw — открытый AI-шлюз (gateway), который запускает AI прямо в вашем мессенджере: WhatsApp, Discord, Feishu, QQ, DingTalk и других.

📚 Официальная документация: [docs.openclaw.ai/zh-CN](https://docs.openclaw.ai/zh-CN)

---

## OpenClaw vs обычный AI-чат

| Функция | OpenClaw | Обычный AI-чат |
|---|---|---|
| Интерфейс | В вашем мессенджере | Отдельный сайт |
| Память | Кроссплатформенная, постоянная | Каждый диалог независим |
| Уведомления | Активная отправка | Только ответы на запросы |
| Данные | Локальные Markdown-файлы | В облаке |
| Кастомизация | Полностью программируемый | Ограниченная |

---

## Установка

```bash
npm install -g openclaw@latest
openclaw --version
```

---

## Первоначальная настройка

```bash
openclaw onboard
```

Рекомендации при прохождении мастера:
- Выберите **QuickStart**
- Шаг с ключом API — **пропустить** (настроим вручную ниже)
- Выберите **All providers**
- Директория — **Keep current**
- Подключение мессенджера — можно пропустить сейчас

---

## Подключение Xinghu API

После настройки в директории OpenClaw появится файл `openclaw.json`. Откройте:

```bash
open ~/.openclaw
```

Замените содержимое файла:

```json
{
  "gateway": { "mode": "local" },
  "agents": {
    "defaults": {
      "model": { "primary": "custom-proxy/claude-sonnet-4-5-20250929" },
      "models": { "custom-proxy/claude-sonnet-4-5-20250929": {} }
    }
  },
  "models": {
    "mode": "merge",
    "providers": {
      "custom-proxy": {
        "baseUrl": "https://xinghuapi.com/v1",
        "apiKey": "sk-ВАШ_КЛЮЧ_XINGHU",
        "api": "openai-completions",
        "models": [{
          "id": "claude-sonnet-4-5-20250929",
          "name": "claude-sonnet-4-5-20250929",
          "contextWindow": 128000,
          "maxTokens": 32000
        }]
      }
    }
  }
}
```

> 💡 Для Gemini: используйте группу `优质gemini2分组` и замените id модели на `gemini-3-pro-preview`

---

## Перезапуск шлюза

```bash
openclaw gateway
```

Для выхода нажмите `Ctrl+C`.
