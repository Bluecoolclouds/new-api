# Gemini CLI

Gemini CLI — официальный open-source инструмент Google для работы с Gemini из командной строки.

**Возможности:**
- 1 млн токенов контекста
- Встроенный поиск Google
- Файловые операции
- Поддержка MCP

---

## Шаг 1: Установка Node.js

Аналогично разделу «Claude Code». Проверьте:
```bash
node --version
```

---

## Шаг 2: Установка Gemini CLI

```bash
npm install -g @google/gemini-cli
gemini --version
```

---

## Шаг 3: Параметры конфигурации

| Параметр | Значение |
|---|---|
| `GEMINI_API_KEY` | Токен Xinghu (формат `sk-`) |
| `GOOGLE_GEMINI_BASE_URL` | `https://xinghuapi.com` |

> 💡 Рекомендуемая группа токена: `优质gemini分组` или `优质gemini2分组`

---

## Шаг 4: Запуск

**Windows:**
```cmd
set GEMINI_API_KEY=sk-...
set GOOGLE_GEMINI_BASE_URL=https://xinghuapi.com
gemini
```

**macOS / Linux:**
```bash
export GEMINI_API_KEY=sk-...
export GOOGLE_GEMINI_BASE_URL=https://xinghuapi.com
gemini
```
