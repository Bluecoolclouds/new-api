# Chatbox

Chatbox — приложение для чата с AI, поддерживает десктоп и веб-версию.

- 🌐 Веб: [web.chatboxai.app](https://web.chatboxai.app/)
- 💻 GitHub: [github.com/chatboxai/chatbox](https://github.com/chatboxai/chatbox)

> 💡 Chatbox поддерживает загрузку изображений и `.txt`-файлов, но не `.doc`/`.docx`.

---

## Настройка

1. Откройте [web.chatboxai.app](https://web.chatboxai.app/) или десктопное приложение
2. Нажмите **«Настройки»**
3. Перейдите в **«Поставщик модели»** → нажмите **➕**
4. Заполните поля:

| Поле | Значение |
|---|---|
| Название | Произвольное (например «Xinghu API») |
| Режим API | OpenAI Compatible |
| API-ключ | Ваш токен из панели управления Xinghu |
| URL API | `https://xinghuapi.com` |

5. Нажмите **«Получить»** для загрузки списка моделей
6. Выберите нужную модель и сохраните
